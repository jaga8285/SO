#ifndef THREAD_INIT
#define THREAD_INIT

typedef struct {
  int  id, size, iter, trab;
} args_mythread_t;

void *thread_func(void *a);

#endif