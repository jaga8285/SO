#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "matrix2d.h"
#include "thread.h"

void *thread_func(void *a){
    DoubleMatrix2D *matrix;
    args_mythread_t *args = (args_mythread_t *) a;

    //printf("Size: " + args -> size);
    matrix = dm2dNew(args->size / args->trab + 2, args->size+2);
    //receberMensagem(0, args->id, matrix, (args->size / args->trab + 2) * (args->size+2));
    return 0;
}
