/*
// Projeto SO - exercicio 1, version 03
// Sistemas Operativos, DEI/IST/ULisboa 2017-18
*/

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <errno.h>

#include "thread.h"
#include "matrix2d.h"

/*--------------------------------------------------------------------
| Types
---------------------------------------------------------------------*/



/*--------------------------------------------------------------------
| Function: Teste de thread
---------------------------------------------------------------------*/

void *thread_print(void *a) {
  args_mythread_t *args = (args_mythread_t *) a;
  printf("Thread: %d", args->id );
  return 0;
}

/*--------------------------------------------------------------------
| Function: parse_integer_or_exit
---------------------------------------------------------------------*/

int parse_integer_or_exit(char const *str, char const *name)
{
  int value;
 
  if(sscanf(str, "%d", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}

/*--------------------------------------------------------------------
| Function: parse_double_or_exit
---------------------------------------------------------------------*/

double parse_double_or_exit(char const *str, char const *name)
{
  double value;

  if(sscanf(str, "%lf", &value) != 1) {
    fprintf(stderr, "\nErro no argumento \"%s\".\n\n", name);
    exit(1);
  }
  return value;
}


/*--------------------------------------------------------------------
| Function: main
---------------------------------------------------------------------*/

int main (int argc, char** argv) {

  if(argc != 9) {
    fprintf(stderr, "\nNumero invalido de argumentos.\n");
    fprintf(stderr, "Uso: heatSim N tEsq tSup tDir tInf iteracoes trab csz\n\n");
    return 1;
  }

  /* argv[0] = program name */
  int N = parse_integer_or_exit(argv[1], "N");
  double tEsq = parse_double_or_exit(argv[2], "tEsq");
  double tSup = parse_double_or_exit(argv[3], "tSup");
  double tDir = parse_double_or_exit(argv[4], "tDir");
  double tInf = parse_double_or_exit(argv[5], "tInf");
  int iteracoes = parse_integer_or_exit(argv[6], "iteracoes");
  int trab = parse_integer_or_exit(argv[7], "trab");
  int csz = parse_integer_or_exit(argv[8], "csz");
  
  args_mythread_t *slave_args;
  int              i;
  pthread_t       *slaves;

  slave_args = (args_mythread_t*)malloc(trab*sizeof(args_mythread_t));
  slaves     = (pthread_t*)malloc(trab*sizeof(pthread_t));

  DoubleMatrix2D *matrix;

  fprintf(stderr, "\nArgumentos:\n"
	" N=%d tEsq=%.1f tSup=%.1f tDir=%.1f tInf=%.1f iteracoes=%d trab=%d csz=%d\n",
	N, tEsq, tSup, tDir, tInf, iteracoes, trab, csz);

  if(N < 1 || tEsq < 0 || tSup < 0 || tDir < 0 || tInf < 0 || iteracoes < 1 || csz < 0) {
    fprintf(stderr, "\nErro: Argumentos invalidos.\n"
	" Lembrar que N >= 1, temperaturas >= 0, iteracoes >= 1 e csz >= 0\n\n");
    return 1;
  }
  if(N % trab != 0){
    fprintf(stderr, "\nErro: Argumentos invalidos.\n"
	" Lembrar que N tem de ser um multiplo de trab\n\n");
    return 1;
  }

  matrix = dm2dNew(N+2, N+2);

  if (matrix == NULL ){
    fprintf(stderr, "\nErro: Nao foi possivel alocar memoria para as matrizes.\n\n");
    return -1;
  }


  for(i=0; i<N+2; i++)
    dm2dSetLineTo(matrix, i, 0);
  dm2dSetLineTo (matrix, 0, tSup);
  dm2dSetLineTo (matrix, N+1, tInf);
  dm2dSetColumnTo (matrix, 0, tEsq);
  dm2dSetColumnTo (matrix, N+1, tDir);
  
  for (i=0; i<trab; i++) {
    printf("creating thread %d \n",trab);
    slave_args[i].id = i+1;
    slave_args[i].size = N;
    slave_args[i].iter = iteracoes;
    slave_args[i].trab = trab;
    pthread_create(&slaves[i], NULL, thread_print, &slave_args[i]);
  }
  for (i=0; i<trab; i++) {
    pthread_join(slaves[i], NULL);
  }
  /*result = simul(matrix, matrix_aux, N+2, N+2, iteracoes);
  if (result == NULL) {
    printf("\nErro na simulacao.\n\n");
    return -1;
  }

  dm2dPrint(result);
  */
  dm2dFree(matrix);

  return 0;
}
